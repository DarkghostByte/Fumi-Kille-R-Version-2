<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class OrdensSeeder extends Seeder
{

    public function run(): void
    {/*
        DB::table('ordens')->insert([
            'id_cliente'=>'1',
            'plague1'=>'2',
            'plague2'=>'3',
            'date1'=>'4',
            'date2'=>'5',
            'time1'=>'6',
            'time2'=>'7',
            'hiring'=>'8',
            'requires'=>'9',
        ]);  
    */}
}
