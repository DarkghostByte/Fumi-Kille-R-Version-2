<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Seeder;

class ClientesSeeder extends Seeder
{

    public function run(): void
    {/*
        DB::table('clientes')->insert([
            'name'=>'Jesus Liadeo',
            'lastname1'=>'Chavez',
            'lastname2'=>'Chavez',
            'tradename'=>'Ez-Biker',
            'street'=>'calle',
            'home'=>'Francisco I. Madero #707',
            'cp'=>'31807',
            'cologne'=>'Madero',
            'id_city'=>'Nuevo Casas Grandes',
            'type_of_place'=>'Comercio',
            'description'=>'Tienda negra con naranja',
            'how_to_get'=>'A 5 calles de una escuela por la principal',
            'cell_phone'=>'6361255070',
            'number_fixed_number'=>'6361255070',
            'contact_form'=>'Facebook',
            'specify'=>'Publicacion',
            'recruitment_data'=>['Presupuesto'],
        ]);  
        DB::table('clientes')->insert([
            'name'=>'Luis Angel',
            'lastname1'=>'Peña',
            'lastname2'=>'Mora',
            'tradename'=>'Ez-Biker',
            'street'=>'calle',
            'home'=>'Francisco I. Madero #707',
            'cp'=>'31807',
            'cologne'=>'Madero',
            'id_city'=>'Nuevo Casas Grandes',
            'type_of_place'=>'Comercio',
            'description'=>'Tienda negra con naranja',
            'how_to_get'=>'A 5 calles de una escuela por la principal',
            'cell_phone'=>'6361255070',
            'number_fixed_number'=>'6361255070',
            'contact_form'=>'Facebook',
            'specify'=>'Publicacion',
        'recruitment_data'=>['Presupuesto'],
        ]);  
        */
    }
}
